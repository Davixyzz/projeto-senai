
  async function carregarRoupas() {
    const container = document.getElementById('produtos-list');
    container.innerHTML = '';

    try {
      const [menRes, womenRes] = await Promise.all([
        fetch("https://fakestoreapi.com/products/category/men's clothing"),
        fetch("https://fakestoreapi.com/products/category/women's clothing")
      ]);

      let roupas = [...await menRes.json(), ...await womenRes.json()];

      // Filtrar apenas títulos com palavras que indicam que é roupa
      roupas = roupas.filter(produto =>
        /shirt|t-shirt|jacket|coat|blazer|slim fit/i.test(produto.title)
      );

      // Eliminar duplicados por título
      const titulosUnicos = new Set();
      roupas = roupas.filter(produto => {
        const titulo = produto.title.trim();
        if (titulosUnicos.has(titulo)) return false;
        titulosUnicos.add(titulo);
        return true;
      });

      // Pegar no máximo 18
      roupas = roupas.slice(0, 18);

      // Montar os cards
      roupas.forEach(produto => {
        const preco = produto.price.toLocaleString('pt-BR', {
          style: 'currency',
          currency: 'BRL'
        });

        const card = document.createElement('div');
        card.className = 'col-6 col-sm-4 col-md-3 col-lg-2';
        card.innerHTML = `
          <div class="card h-100">
            <img src="${produto.image}" class="card-img-top" alt="${produto.title}" style="height: 180px; object-fit: contain;">
            <div class="card-body text-center">
              <h6 class="card-title mb-1">${produto.title}</h6>
              <p class="card-text text-primary fw-bold mb-0">${preco}</p>
            </div>
          </div>
        `;
        container.appendChild(card);
      });

      if (roupas.length === 0) {
        container.innerHTML = '<p class="text-muted">Nenhuma roupa encontrada.</p>';
      }

    } catch (erro) {
      console.error('Erro ao carregar roupas:', erro);
      container.innerHTML = '<p class="text-danger">Erro ao carregar os produtos.</p>';
    }
  }

  document.addEventListener('DOMContentLoaded', carregarRoupas);

